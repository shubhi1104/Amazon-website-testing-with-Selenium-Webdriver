package MyExample.MyExample;

import java.io.File;
import java.io.IOException;


import org.apache.commons.io.FileUtils;
import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import junit.framework.Assert;

public class AppTest {
	
static ExtentReports reports;
 ExtentTest test;
 static WebDriver driver = null;
 String screenShotPath;
 
 @Before
 public void openBrowser() throws InterruptedException{
	System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
	 driver = new ChromeDriver();
	 //driver = new FirefoxDriver();
	 driver.manage().window().maximize(); 
 
}
@Test 
public void hello0() throws InterruptedException {
	
	try {
		/*driver.get("http://127.0.0.1:32767/start.html#p=home_page&g=1");
		Thread.sleep(2000);
		WebElement element = driver.findElement(By.id("u13_input"));
		 //WebElement element = driver.findElement(By.xpath(("//*[@id=\"u13_input\"]")));
	     element.sendKeys("QA Engineer");
	     WebElement element1 = driver.findElement(By.id("u14_input"));
	     element1.sendKeys("Cambridge");
	     WebElement element2 = driver.findElement(By.id("u15_input"));
	     element2.sendKeys("Amazon");
	     Thread.sleep(2000);
	      driver.findElement(By.id("u16_img")).click();
	      Thread.sleep(2000);
	      driver.findElement(By.id("u27_div")).click();
	      Thread.sleep(4000);
		*/
		
		
		
		
		
		
		// amazon create account page

		 reports = new ExtentReports(System.getProperty("user.dir") + "/HtmlReport/index0.html", true);  
		
		reports = new ExtentReports("C:\\workspace_SeleniumTest\\MyExample\\HtmlReport\\index0.html", true);
		 
		 driver.get("https://www.amazon.com/ap/register?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com");
		 WebElement element = driver.findElement(By.id("ap_customer_name"));
	     element.sendKeys("Shubhi Sharma");
	     WebElement element1 = driver.findElement(By.id("ap_email"));
	     element1.sendKeys("shubhi.sharma1104@gmail.com");
	     WebElement element2 = driver.findElement(By.id("ap_password"));
	     element2.sendKeys("Shubhi1104");
	     WebElement element3 = driver.findElement(By.id("ap_password_check"));
	     element3.sendKeys("Shubhi1104");
	      driver.findElement(By.id("continue")).click();
	     Thread.sleep(2000);
	    // driver.findElement(By.xpath("//*[@id=\"ap_register_form\"]/div/div/div[6]/a")).click();
	     if(driver.getTitle().equalsIgnoreCase("Please confirm your identity")){
		    	 screenShotPath = System.getProperty("user.dir") + "/Screenshots/createaccountsucessscreen0.png";
		    	 takeScreenShot(driver, screenShotPath);
		     Assert.assertEquals("Passed", "Please confirm your identity",driver.getTitle());
		 	}else{
		 		 screenShotPath = System.getProperty("user.dir") + "/Screenshots/createaccountfailedscreen0.png";
		    	 takeScreenShot(driver, screenShotPath);
		    	 Assert.assertEquals("Failed", "Please confirm your identity",driver.getTitle());
		 	}
	     
		
	}
		catch(Exception e) {
			   e.printStackTrace();	
		
	}
}
	

@Ignore
public void hello1() throws InterruptedException {
	
	try {
		
		//amazon signin page
		 reports = new ExtentReports(System.getProperty("user.dir") + "/HtmlReport/index1.html", true);
		 driver.get("https://www.amazon.com/ap/signin?_encoding=UTF8&openid.assoc_handle=usflex&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.ns.pape=http%3A%2F%2Fspecs.openid.net%2Fextensions%2Fpape%2F1.0&openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.com%2Fgp%2Fyourstore%2Fhome%3Fie%3DUTF8%26action%3Dsign-out%26path%3D%252Fgp%252Fyourstore%252Fhome%26ref_%3Dnav_youraccount_signout%26signIn%3D1%26useRedirectOnSuccess%3D1");
	     Thread.sleep(2000);
	 
		 WebElement element4 = driver.findElement(By.id("ap_email"));
	     element4.sendKeys("sharma.shub@husky.neu.edu");  
	     Thread.sleep(2000);
	     //driver.findElement(By.id("continue")).click();
	     //Thread.sleep(2000);
	     WebElement element5 = driver.findElement(By.id("ap_password"));
	     element5.sendKeys("shubhi11");
	     Thread.sleep(2000);
	     driver.findElement(By.id("signInSubmit")).click();
	     Thread.sleep(2000);
	     if(driver.getTitle().equalsIgnoreCase("Your Amazon.com")){
	    	 screenShotPath = System.getProperty("user.dir") + "/Screenshots/signinsucessscreen1.png";
	    	 takeScreenShot(driver, screenShotPath);
	    	 Assert.assertEquals("Passed", "Your Amazon.com",driver.getTitle());
	 	}else{
	 		 screenShotPath = System.getProperty("user.dir") + "/Screenshots/signinfailedscreen1.png";
	    	 takeScreenShot(driver, screenShotPath);
	    	 Assert.assertEquals("Failed", "Your Amazon.com", driver.getTitle());
	 	}
	    
	    
	}
		catch(Exception e) {
			   e.printStackTrace();	
		}	
		
		
	}


     
     

    
  @Ignore
  public void hello2() throws InterruptedException {    
   try {
   
            
	   //reports = new ExtentReports(System.getProperty("user.dir") + "/HtmlReport/index.html", true);
	  
	  
	 //amazon inside
	   reports = new ExtentReports(System.getProperty("user.dir") + "/HtmlReport/index2.html", true);
	   
	     driver.get("https://www.amazon.com/ref=nav_logo");
	     Thread.sleep(2000);
	     WebElement element2 = driver.findElement(By.id("twotabsearchtextbox"));
	 // WebElement element2 = driver.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]"));
	     element2.sendKeys("pencil");
	     Thread.sleep(2000);
	 	 driver.findElement(By.className("nav-input")).click();// search button
	 	 Thread.sleep(2000);
	 	 driver.findElement(By.xpath("//*[@id=\"pdagDesktopSparkleAsinsContainer\"]/div[1]/div[2]/a/div")).click();//item link
	 	 Thread.sleep(2000);
	 	 driver.findElement(By.id("add-to-cart-button")).click();// add to cart button
	 	 Thread.sleep(2000);
	 	 driver.findElement(By.id("hlb-ptc-btn-native")).click();// proceed to checkout button
	 	 Thread.sleep(2000);
	 	 if(driver.getTitle().equalsIgnoreCase("Place Your Order - Amazon.com Checkout")){
	    	 screenShotPath = System.getProperty("user.dir") + "/Screenshots/checkoutsucessscreen2.png";
	    	 takeScreenShot(driver, screenShotPath);
	    	 Assert.assertEquals("Passed", "Place Your Order - Amazon.com Checkout",driver.getTitle());
	 	}else{
	 		 screenShotPath = System.getProperty("user.dir") + "/Screenshots/checkoutfailedscreen2.png";
	    	 takeScreenShot(driver, screenShotPath);
	    	 Assert.assertEquals("Failed", "Place Your Order - Amazon.com Checkout",driver.getTitle());
	 	}
	 	   
		     
		    }
   catch(Exception e) {
	   e.printStackTrace();
   }
 }
  
  
  
  @After
  public void closeBrowser() throws InterruptedException {
	  reports.endTest(test);
	  reports.flush();
	  Thread.sleep(5000);
	 driver.quit();
  }
  
  public void takeScreenShot(WebDriver driver, String filePath) {
      File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
      try {
          FileUtils.copyFile(scrFile, new File(filePath));
      } catch (IOException e) {
          e.printStackTrace();
      }
  }
}